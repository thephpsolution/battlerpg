<?php

/* ::layout.html.twig */
class __TwigTemplate_5e118865294fe7ce437ab9498f01d43d520bbeb440c5b98c096d8eae038f3df3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::layout.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'additional_stylesheets' => array($this, 'block_additional_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'additional_javascripts' => array($this, 'block_additional_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d52ef2338863b921fc6b838083c170f2a8bd2a5c333c2e6b0eb75f8177ad2c4e = $this->env->getExtension("native_profiler");
        $__internal_d52ef2338863b921fc6b838083c170f2a8bd2a5c333c2e6b0eb75f8177ad2c4e->enter($__internal_d52ef2338863b921fc6b838083c170f2a8bd2a5c333c2e6b0eb75f8177ad2c4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d52ef2338863b921fc6b838083c170f2a8bd2a5c333c2e6b0eb75f8177ad2c4e->leave($__internal_d52ef2338863b921fc6b838083c170f2a8bd2a5c333c2e6b0eb75f8177ad2c4e_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c57d537c633183dc709b48f89ff32f674597d0948f7d9ae36af6dce7cb4242dd = $this->env->getExtension("native_profiler");
        $__internal_c57d537c633183dc709b48f89ff32f674597d0948f7d9ae36af6dce7cb4242dd->enter($__internal_c57d537c633183dc709b48f89ff32f674597d0948f7d9ae36af6dce7cb4242dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"http://cdn.leafletjs.com/leaflet-0.7.1/leaflet.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/css/bootstrap-theme.min.css"), "html", null, true);
        echo "\" />
";
        // line 7
        $this->displayBlock('additional_stylesheets', $context, $blocks);
        
        $__internal_c57d537c633183dc709b48f89ff32f674597d0948f7d9ae36af6dce7cb4242dd->leave($__internal_c57d537c633183dc709b48f89ff32f674597d0948f7d9ae36af6dce7cb4242dd_prof);

    }

    public function block_additional_stylesheets($context, array $blocks = array())
    {
        $__internal_3931956924d947e709f3b467ef187c0a9034c3dc306ffa857cf45aa4474d8bf4 = $this->env->getExtension("native_profiler");
        $__internal_3931956924d947e709f3b467ef187c0a9034c3dc306ffa857cf45aa4474d8bf4->enter($__internal_3931956924d947e709f3b467ef187c0a9034c3dc306ffa857cf45aa4474d8bf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_stylesheets"));

        
        $__internal_3931956924d947e709f3b467ef187c0a9034c3dc306ffa857cf45aa4474d8bf4->leave($__internal_3931956924d947e709f3b467ef187c0a9034c3dc306ffa857cf45aa4474d8bf4_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_40736247d788bbc2c7f41a5811ec12f544cf1b7eaa04751a746f9119a140a5b5 = $this->env->getExtension("native_profiler");
        $__internal_40736247d788bbc2c7f41a5811ec12f544cf1b7eaa04751a746f9119a140a5b5->enter($__internal_40736247d788bbc2c7f41a5811ec12f544cf1b7eaa04751a746f9119a140a5b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 12
        echo "    ";
        // line 13
        echo "    ";
        // line 14
        echo "        ";
        // line 15
        echo "        ";
        // line 16
        echo "            ";
        // line 17
        echo "        ";
        // line 18
        echo "    ";
        // line 19
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery-ui/jquery-ui.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery-mousewheel/jquery.mousewheel.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>

    ";
        // line 24
        $this->displayBlock('additional_javascripts', $context, $blocks);
        
        $__internal_40736247d788bbc2c7f41a5811ec12f544cf1b7eaa04751a746f9119a140a5b5->leave($__internal_40736247d788bbc2c7f41a5811ec12f544cf1b7eaa04751a746f9119a140a5b5_prof);

    }

    public function block_additional_javascripts($context, array $blocks = array())
    {
        $__internal_343a0c429b5d7bc7d807712c2814ad057946924d1004806ae5ceb9fee265d405 = $this->env->getExtension("native_profiler");
        $__internal_343a0c429b5d7bc7d807712c2814ad057946924d1004806ae5ceb9fee265d405->enter($__internal_343a0c429b5d7bc7d807712c2814ad057946924d1004806ae5ceb9fee265d405_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_javascripts"));

        
        $__internal_343a0c429b5d7bc7d807712c2814ad057946924d1004806ae5ceb9fee265d405->leave($__internal_343a0c429b5d7bc7d807712c2814ad057946924d1004806ae5ceb9fee265d405_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 24,  104 => 22,  100 => 21,  96 => 20,  91 => 19,  89 => 18,  87 => 17,  85 => 16,  83 => 15,  81 => 14,  79 => 13,  77 => 12,  71 => 11,  54 => 7,  50 => 6,  46 => 5,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "base.html.twig" %}*/
/* */
/* {% block stylesheets %}*/
/*     <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.1/leaflet.css" />*/
/*     <link rel="stylesheet" href="{{ asset('assets/vendor/bootstrap/dist/css/bootstrap.min.css') }}" />*/
/*     <link rel="stylesheet" href="{{ asset('assets/vendor/bootstrap/dist/css/bootstrap-theme.min.css') }}" />*/
/* {% block additional_stylesheets %}*/
/* {% endblock %}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {#<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.2.6/angular.min.js"></script>#}*/
/*     {#<script>#}*/
/*         {#var app = angular.module("battlerpg", ['leaflet-directive']);#}*/
/*         {#app.controller("BattleRpg", [ "$scope", function($scope) {#}*/
/*             {#// Nothing here!#}*/
/*         {#}]);#}*/
/*     {#</script>#}*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery/dist/jquery.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery-ui/jquery-ui.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery-mousewheel/jquery.mousewheel.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.min.js') }}"></script>*/
/* */
/*     {% block additional_javascripts %}*/
/* {% endblock %}*/
/* {% endblock %}*/

<?php

/* base.html.twig */
class __TwigTemplate_9146fe88f702ccca58b039958460a81c05a11ee808a1905414cbba4e29339e07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c37fffd9a4321a983aa143920ded06e28557342fbec119224befd16fea6000b5 = $this->env->getExtension("native_profiler");
        $__internal_c37fffd9a4321a983aa143920ded06e28557342fbec119224befd16fea6000b5->enter($__internal_c37fffd9a4321a983aa143920ded06e28557342fbec119224befd16fea6000b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_c37fffd9a4321a983aa143920ded06e28557342fbec119224befd16fea6000b5->leave($__internal_c37fffd9a4321a983aa143920ded06e28557342fbec119224befd16fea6000b5_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b10cc07efa34f14054ff5c61ae45ad6c5f0e4e21fd78acf49292a304dca0bdee = $this->env->getExtension("native_profiler");
        $__internal_b10cc07efa34f14054ff5c61ae45ad6c5f0e4e21fd78acf49292a304dca0bdee->enter($__internal_b10cc07efa34f14054ff5c61ae45ad6c5f0e4e21fd78acf49292a304dca0bdee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_b10cc07efa34f14054ff5c61ae45ad6c5f0e4e21fd78acf49292a304dca0bdee->leave($__internal_b10cc07efa34f14054ff5c61ae45ad6c5f0e4e21fd78acf49292a304dca0bdee_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b0a9dfd5fc08073a0db36292e1836cd16ced38030b30533c5acac47f942a6a11 = $this->env->getExtension("native_profiler");
        $__internal_b0a9dfd5fc08073a0db36292e1836cd16ced38030b30533c5acac47f942a6a11->enter($__internal_b0a9dfd5fc08073a0db36292e1836cd16ced38030b30533c5acac47f942a6a11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b0a9dfd5fc08073a0db36292e1836cd16ced38030b30533c5acac47f942a6a11->leave($__internal_b0a9dfd5fc08073a0db36292e1836cd16ced38030b30533c5acac47f942a6a11_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_ff976a8874820f9285b190896ef54d94c036e26081e439f6489aca6f3560cac2 = $this->env->getExtension("native_profiler");
        $__internal_ff976a8874820f9285b190896ef54d94c036e26081e439f6489aca6f3560cac2->enter($__internal_ff976a8874820f9285b190896ef54d94c036e26081e439f6489aca6f3560cac2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_ff976a8874820f9285b190896ef54d94c036e26081e439f6489aca6f3560cac2->leave($__internal_ff976a8874820f9285b190896ef54d94c036e26081e439f6489aca6f3560cac2_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3338cb051903aecc736ed33a43a21335cb96f1c3fce61a577bd4892383a4e174 = $this->env->getExtension("native_profiler");
        $__internal_3338cb051903aecc736ed33a43a21335cb96f1c3fce61a577bd4892383a4e174->enter($__internal_3338cb051903aecc736ed33a43a21335cb96f1c3fce61a577bd4892383a4e174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3338cb051903aecc736ed33a43a21335cb96f1c3fce61a577bd4892383a4e174->leave($__internal_3338cb051903aecc736ed33a43a21335cb96f1c3fce61a577bd4892383a4e174_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */

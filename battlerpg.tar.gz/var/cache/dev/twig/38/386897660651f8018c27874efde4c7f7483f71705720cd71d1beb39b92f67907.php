<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_4a1e0f0b3a27081973a9e4dc24ec47fa29cf0d06331868ea37411b5c8fe3ce8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba5e0dce8847d1a7ac394c2bcc5cac56bee328fadb388dc289e3619499ca3f26 = $this->env->getExtension("native_profiler");
        $__internal_ba5e0dce8847d1a7ac394c2bcc5cac56bee328fadb388dc289e3619499ca3f26->enter($__internal_ba5e0dce8847d1a7ac394c2bcc5cac56bee328fadb388dc289e3619499ca3f26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ba5e0dce8847d1a7ac394c2bcc5cac56bee328fadb388dc289e3619499ca3f26->leave($__internal_ba5e0dce8847d1a7ac394c2bcc5cac56bee328fadb388dc289e3619499ca3f26_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_975ef71a4a3cb0f70e9617fb7b655fdf4c0d5bcf7ddc9f99912ab154e42c48d1 = $this->env->getExtension("native_profiler");
        $__internal_975ef71a4a3cb0f70e9617fb7b655fdf4c0d5bcf7ddc9f99912ab154e42c48d1->enter($__internal_975ef71a4a3cb0f70e9617fb7b655fdf4c0d5bcf7ddc9f99912ab154e42c48d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_975ef71a4a3cb0f70e9617fb7b655fdf4c0d5bcf7ddc9f99912ab154e42c48d1->leave($__internal_975ef71a4a3cb0f70e9617fb7b655fdf4c0d5bcf7ddc9f99912ab154e42c48d1_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_a83712eb308cf81d0ae1c48e968c95597ac6776bf1aae6fbcd1cf1188eeab50c = $this->env->getExtension("native_profiler");
        $__internal_a83712eb308cf81d0ae1c48e968c95597ac6776bf1aae6fbcd1cf1188eeab50c->enter($__internal_a83712eb308cf81d0ae1c48e968c95597ac6776bf1aae6fbcd1cf1188eeab50c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_a83712eb308cf81d0ae1c48e968c95597ac6776bf1aae6fbcd1cf1188eeab50c->leave($__internal_a83712eb308cf81d0ae1c48e968c95597ac6776bf1aae6fbcd1cf1188eeab50c_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_a99652cf7fe4661cf33ef6ff8af8097dff91f8592938be6a82744c733f212ebb = $this->env->getExtension("native_profiler");
        $__internal_a99652cf7fe4661cf33ef6ff8af8097dff91f8592938be6a82744c733f212ebb->enter($__internal_a99652cf7fe4661cf33ef6ff8af8097dff91f8592938be6a82744c733f212ebb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_a99652cf7fe4661cf33ef6ff8af8097dff91f8592938be6a82744c733f212ebb->leave($__internal_a99652cf7fe4661cf33ef6ff8af8097dff91f8592938be6a82744c733f212ebb_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */

<?php

/* AppBundle:Map:view.html.twig */
class __TwigTemplate_23e486857e6b58f7a5c851f8bf98888a9302c77195b7d429c955faf52c418ded extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::layout.html.twig", "AppBundle:Map:view.html.twig", 1);
        $this->blocks = array(
            'additional_javascripts' => array($this, 'block_additional_javascripts'),
            'additional_stylesheets' => array($this, 'block_additional_stylesheets'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_352503311fd257f72c13a0ff0c2c50d715db61a5ee72384dba50eaa53127adce = $this->env->getExtension("native_profiler");
        $__internal_352503311fd257f72c13a0ff0c2c50d715db61a5ee72384dba50eaa53127adce->enter($__internal_352503311fd257f72c13a0ff0c2c50d715db61a5ee72384dba50eaa53127adce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Map:view.html.twig"));

        // line 357
        $context["macros"] = $this;
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_352503311fd257f72c13a0ff0c2c50d715db61a5ee72384dba50eaa53127adce->leave($__internal_352503311fd257f72c13a0ff0c2c50d715db61a5ee72384dba50eaa53127adce_prof);

    }

    // line 2
    public function block_additional_javascripts($context, array $blocks = array())
    {
        $__internal_32fcf090d9c91c52a05bf1007e983ea46486d623e0a91cba9e20ec96ef344d95 = $this->env->getExtension("native_profiler");
        $__internal_32fcf090d9c91c52a05bf1007e983ea46486d623e0a91cba9e20ec96ef344d95->enter($__internal_32fcf090d9c91c52a05bf1007e983ea46486d623e0a91cba9e20ec96ef344d95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_javascripts"));

        // line 3
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/iviewer/jquery.iviewer.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/jquery-canvas-area-draw/jquery.canvasAreaDraw.js"), "html", null, true);
        echo "\" ></script>

    <script type=\"text/javascript\">
        jQuery(function(\$){

            var viewer, app;

            function isInCircle(x, y) {
                var relative_x = x - this.x;
                var relative_y = y - this.y;
                return Math.sqrt(relative_x*relative_x + relative_y*relative_y) <= this.r;
            }

            function isInRectangle(x, y) {
                return (this.x1 <= x && x <= this.x2) && (this.y1 <= y && y<= this.y2);
            }

            function getCircleCenter() { return {x: this.x, y: this.y}; }

            function getRectangleCenter() { return {x: (this.x2+this.x1)/2, y: (this.y2+this.y1)/2}; }

            var objects = [
                {x: 100, y: 100, r: 50, isInObject: isInCircle, title: 'big circle', getCenter: getCircleCenter },
                {x: 150, y: 250, r: 35, isInObject: isInCircle, title: 'middle circle', getCenter: getCircleCenter },
                {x: 500, y: 300, r: 10, isInObject: isInCircle, title: 'small circle', getCenter: getCircleCenter },
                {x1: 200, y1: 400, x2: 300, y2: 500, isInObject: isInRectangle, title: 'rectangle', getCenter: getRectangleCenter }
            ]

            function whereIam(x, y) {
                for (var i=0; i<objects.length; i++) {
                    var obj = objects[i];
                    if (obj.isInObject(x, y))
                        return obj;
                }

                return null;
            }

            function showMe(ev, a) {
                \$.each(objects, function(i, object) {
                    if (object.title == \$(a).html()) {
                        var center = object.getCenter();
                        var offset = viewer.iviewer('imageToContainer', center.x, center.y);
                        var containerOffset = viewer.iviewer('getContainerOffset');
                        var pointer = \$('#pointer');
                        offset.x += containerOffset.left - 20;
                        offset.y += containerOffset.top - 40;
                        pointer.css('display', 'block');
                        pointer.css('left', offset.x+'px');
                        pointer.css('top', offset.y+'px');
                    }
                });

                ev.preventDefault();
            }

            window.showMe = showMe;

            viewer = \$(\"#viewer1\").iviewer({
                src: \"/bundles/app/map.jpg\",
                zoom: 125,

                onClick: function(ev, coords) {
                    console.log('Mark mountain at ' + coords.x + \", \" + coords.y);
                    var object = whereIam(coords.x, coords.y);

                    if (object)
                        alert('Clicked at ('+coords.x+', '+coords.y+'). This is '+object.title);
                },

                onMouseMove: function(ev, coords) {
                    var object = whereIam(coords.x, coords.y);

                    if (object) {
                        \$('#status').html('You are in ('+coords.x.toFixed(1)+', '+coords.y.toFixed(1)+'). This is '+object.title);
                        this.container.css('cursor', 'crosshair');
                    } else {
                        \$('#status').html('You are in ('+coords.x.toFixed(1)+', '+coords.y.toFixed(1)+'). This is empty space');
                        this.container.css('cursor', null);
                    }
                },

                onBeforeDrag: function(ev, coords) {
                    // remove pointer if image is getting moving
                    // because it's not actual anymore
                    \$('#pointer').css('display', 'none');
                    // forbid dragging when cursor is whithin the object
                    return whereIam(coords.x, coords.y) ? false : true;
                },

                onZoom: function(ev) {
                    // remove pointer if image is resizing
                    // because it's not actual anymore
                    \$('#pointer').css('display', 'none');
                },

                initCallback: function(ev) {
                    this.container.context.iviewer = this;
                }
            });
        });

        function findCentroid(points) {
            var centroid = [0, 0];

            for (var i = 0; i < points.length; i+=2) {
                centroid[0] += points[i];
                centroid[1] += points[i+1];
            }

            var totalPoints = points.length/2;
            centroid[0] = centroid[0] / totalPoints;
            centroid[1] = centroid[1] / totalPoints;

            return centroid;
        };

        function findMidpoint(x1, y1, x2, y2) {
            return [
                (x1 + x2) / 2,
                (y1 + y2) / 2
            ];
        };
        function findDistance(x1, y1, x2, y2) {
            return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        };

        function findMinMax(points) {
            var solution = {
                points: 0,
                midpoint: [0, 0],
                area: 0,
                longest: [[0, 0], [0, 0]],
                longestDistance: 0,
                lowest: [0, 0],
                greatest: [0, 0]
            };
            for (var i = 0; i < points.length; i+=4) {
                var x = points[i],
                    y = points[i+2],
                    x2 = points[i+1],
                    y2 = points[i+3]
                ;
                if (solution.points == 0) {
                    var midpoint = findMidpoint(x, y, x2, y2);
                    var d1 = findDistance(x);
                    var centroid = findCentroid(points);

                    solution = {
                        points: 1,
                        midpoint: [centroid[0], centroid[1]],
                        longest: [[x, y], [x2, y2]],
                        longestDistance: d1,
                        area: 0,
                        lowest: [, 0],
                        greatest: [0, 0]
                    };
                    continue;
                }
            }
        };

        var app = {};


        var editor = new function() {
            this.mode = null;
            this.context = null;
            this.dirty = false;
            this.data = {
                'Mountain': [[
                    549,194,549,316,563,339,517,372,533,386,566,373,585,370,597,379,637,372,665,365,669,376,717,381,790,399,811,382,807,371,698,329,680,282,663,278,645,292,626,271,604,263,621,247,606,232,597,234,596,198,582,183,568,187
                ]],
                'Tree': [],
                'Water': [],
                'Boundary': [],
                'Path': [],
                'Field': []
            };

            this.reset = function() {
                var ctx = \$('canvas')[0].getContext('2d');
                \$('.editor-reset').click();
                this.dirty = false;
                this.drawLayers();
            };

            this.finish = function() {
                var data = this.data[this.mode];
                data[data.length] = \$('#map-points').val().split(',');
                for (var i = 0; i < data.length; i++) {
                    for (var j = 0; j < data[i].length; j++) {
                        data[i][j] = parseInt(data[i][j]);

                    }
                }
                this.reset();
            };

            this.drawLayers = function() {
                if (!this.context) {
                    var ctx = \$('canvas')[0].getContext('2d');
                    this.context = ctx;
                }
                var context = this.context;
                console.log(this.data);
                for (var mode in this.data) {
                    for (var i = 0; i < this.data[mode].length; i++) {

                        var centroid = findCentroid(this.data[mode][i]);
                        var base_image = new Image();
                        base_image.src = 'bundles/app/' + mode.toLowerCase() + '.png';
                        context.drawImage(base_image, centroid[0] - 50, centroid[1] - 50, 100, 100);
                    }
                }

//                console.log(findCentroid(points2));
//                context.moveTo(20, 20);
//                context.lineTo(100, 20);
//                context.fillStyle = \"#999\";
//                context.beginPath();
//                context.arc(100,100,75,0,2*Math.PI);
//                context.fill();
//                context.fillStyle = \"orange\";
//                context.fillRect(20,20,50,50);
//                context.font = \"24px Helvetica\";
//                context.fillStyle = \"#000\";
//                context.fillText(\"Canvas\", 50, 130);

            };
        };
        \$('.editor-mode').change(function() {
            if (editor.dirty) {
                if (!window.confirm('There are unsaved changes.Discard?')) {
                    return;
                }
            }
            editor.mode = \$(this).val();
            editor.reset();
        });

        \$('.editor-cancel').click(function() {
            editor.reset();
        });

        \$('.editor-finish').click(function() {
            editor.finish();
        });

        \$(document).ready(function() {

            \$('#mark_mountains').change(function() {
                app.mode = 'mark_mountains';
            });


            window.setTimeout(function() {
                editor.reset();
            }, 500);
        });
    </script>
";
        
        $__internal_32fcf090d9c91c52a05bf1007e983ea46486d623e0a91cba9e20ec96ef344d95->leave($__internal_32fcf090d9c91c52a05bf1007e983ea46486d623e0a91cba9e20ec96ef344d95_prof);

    }

    // line 268
    public function block_additional_stylesheets($context, array $blocks = array())
    {
        $__internal_b0e7a8128c5cb15c3ec3375b0ba855cadf6d0cf8a3880a166f8b387a7a737348 = $this->env->getExtension("native_profiler");
        $__internal_b0e7a8128c5cb15c3ec3375b0ba855cadf6d0cf8a3880a166f8b387a7a737348->enter($__internal_b0e7a8128c5cb15c3ec3375b0ba855cadf6d0cf8a3880a166f8b387a7a737348_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_stylesheets"));

        // line 269
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/iviewer/jquery.iviewer.css"), "html", null, true);
        echo "\" />
    <style>
        html, body {
            height: 100%;
            padding: 0;
            margin: 0;
        }

        .viewer
        {
            height: 100%;
            position: relative;
            background-color: lightgreen;
        }

        .wrapper
        {
            border: 1px solid black;

            position: absolute;
            top: 5em;
            left: 1em;
            bottom: 1em;
            right: 1em;

            overflow: hidden; /*for opera*/
        }

        .toolbar
        {
            border: 1px solid black;

            position: absolute;
            top: 1em;
            left: 1em;
            right: 1em;
            height: 3em;
        }

        #pointer
        {
            background-image: url('";
        // line 310
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/arrow.png"), "html", null, true);
        echo "');
            width: 40px;
            height: 40px;
            position: absolute;
            display: none;
        }
        #editor-bar {
            height: 5em;
            position: fixed;
            top: 0;
            left: 20vw;
            /*width: 20vw;*/
            padding: 1vh;
            vertical-align: text-top;
            margin: auto;
            color: white;
            font-weight: bold;
            text-align: center;
            background: rgba(0, 0, 0, 0.4);

            /*background: #6a3093; !* fallback for old browsers *!*/
            /*background: -webkit-linear-gradient(to top, #6a3093 , #a044ff); !* Chrome 10-25, Safari 5.1-6 *!*/
            /*background: linear-gradient(to top, #6a3093 , #a044ff); !* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ *!*/

        }

        .editor-button {
            font-size: 2em;
            /*width: 3.2em;*/
            height: 5vh;
            /*background: rgba(250, 250, 250, 0.7);*/
            /*background-image: url(...);*/
            /*background-repeat: no-repeat;*/
            /*background-position: <left|right>;*/
            /*padding-<left|right>: <width of image>px;*/
        }
        .editor-button > img {
            height: 4vh;
            /*width: 3.2em;*/
            margin-left: -0.2em;
            margin-topt: -0.8em;
        }

    </style>
    <link href=\"";
        // line 354
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
";
        
        $__internal_b0e7a8128c5cb15c3ec3375b0ba855cadf6d0cf8a3880a166f8b387a7a737348->leave($__internal_b0e7a8128c5cb15c3ec3375b0ba855cadf6d0cf8a3880a166f8b387a7a737348_prof);

    }

    // line 367
    public function block_body($context, array $blocks = array())
    {
        $__internal_e4ac6fb9438daafc85c75dbe3be95fd312b8b0c8daee599553bd486fddf2d519 = $this->env->getExtension("native_profiler");
        $__internal_e4ac6fb9438daafc85c75dbe3be95fd312b8b0c8daee599553bd486fddf2d519->enter($__internal_e4ac6fb9438daafc85c75dbe3be95fd312b8b0c8daee599553bd486fddf2d519_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 368
        echo "    <div id=\"editor-bar\">
    <div class=\"btn-group\" data-toggle=\"buttons\">
        ";
        // line 370
        echo $context["macros"]->getbutton("mountain.png", "M", "Mountain");
        echo "
        ";
        // line 371
        echo $context["macros"]->getbutton("water.png", "W", "Water");
        echo "
        ";
        // line 372
        echo $context["macros"]->getbutton("boundary.png", "B", "Boundary");
        echo "
        ";
        // line 373
        echo $context["macros"]->getbutton("trees.png", "T", "Tree");
        echo "
        ";
        // line 374
        echo $context["macros"]->getbutton("path.png", "P", "Path");
        echo "
        ";
        // line 375
        echo $context["macros"]->getbutton("field.png", "F", "Field");
        echo "
        <button class=\"editor-button editor-finish btn btn-success\">Finish</button>
        <button class=\"editor-button editor-cancel btn btn-danger reset\">Cancel</button>
    </div>
    </div>
        <form>
            <div class=\"row\">
                <div class=\"span6\">
      <textarea id=\"map-points\" rows=3 style=\"display: none; width: 0; height: 0; padding: 0; border: 0;\" name=\"coords1\" class=\"canvas-area input-xxlarge\" disabled
                placeholder=\"Shape Coordinates\"
                data-image-url=\"";
        // line 385
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/map.jpg"), "html", null, true);
        echo "\">549,194,549,316,563,339,517,372,533,386,566,373,585,370,597,379,637,372,665,365,669,376,717,381,790,399,811,382,807,371,698,329,680,282,663,278,645,292,626,271,604,263,621,247,606,232,597,234,596,198,582,183,568,187</textarea>
                </div>
            </div>
        </form>
";
        
        $__internal_e4ac6fb9438daafc85c75dbe3be95fd312b8b0c8daee599553bd486fddf2d519->leave($__internal_e4ac6fb9438daafc85c75dbe3be95fd312b8b0c8daee599553bd486fddf2d519_prof);

    }

    // line 359
    public function getbutton($__image__ = null, $__key__ = null, $__title__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "image" => $__image__,
            "key" => $__key__,
            "title" => $__title__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            $__internal_b1c72c358c710ef88c62c094f7e2f3d3aa4e4665bada9b226fa3399d49ef4a12 = $this->env->getExtension("native_profiler");
            $__internal_b1c72c358c710ef88c62c094f7e2f3d3aa4e4665bada9b226fa3399d49ef4a12->enter($__internal_b1c72c358c710ef88c62c094f7e2f3d3aa4e4665bada9b226fa3399d49ef4a12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "macro", "button"));

            // line 360
            echo "        <label class=\"editor-button btn btn-primary active\">
            <input type=\"radio\" class=\"editor-button editor-mode btn btn-primary\" name=\"mode\" value=\"";
            // line 361
            echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : $this->getContext($context, "title")), "html", null, true);
            echo "\">
                <img src=\"";
            // line 362
            echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl(("bundles/app/" . (isset($context["image"]) ? $context["image"] : $this->getContext($context, "image")))), "html", null, true);
            echo "\"    alt=\"";
            echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key")), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, (isset($context["title"]) ? $context["title"] : $this->getContext($context, "title")), "html", null, true);
            echo "\"/>
            </input>
        </label>
";
            
            $__internal_b1c72c358c710ef88c62c094f7e2f3d3aa4e4665bada9b226fa3399d49ef4a12->leave($__internal_b1c72c358c710ef88c62c094f7e2f3d3aa4e4665bada9b226fa3399d49ef4a12_prof);

        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "AppBundle:Map:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  507 => 362,  503 => 361,  500 => 360,  483 => 359,  471 => 385,  458 => 375,  454 => 374,  450 => 373,  446 => 372,  442 => 371,  438 => 370,  434 => 368,  428 => 367,  419 => 354,  372 => 310,  327 => 269,  321 => 268,  52 => 5,  48 => 4,  45 => 3,  39 => 2,  32 => 1,  30 => 357,  11 => 1,);
    }
}
/* {% extends "::layout.html.twig" %}*/
/* {% block additional_javascripts %}*/
/* */
/*     <script type="text/javascript" src="{{ asset('assets/vendor/iviewer/jquery.iviewer.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/jquery-canvas-area-draw/jquery.canvasAreaDraw.js') }}" ></script>*/
/* */
/*     <script type="text/javascript">*/
/*         jQuery(function($){*/
/* */
/*             var viewer, app;*/
/* */
/*             function isInCircle(x, y) {*/
/*                 var relative_x = x - this.x;*/
/*                 var relative_y = y - this.y;*/
/*                 return Math.sqrt(relative_x*relative_x + relative_y*relative_y) <= this.r;*/
/*             }*/
/* */
/*             function isInRectangle(x, y) {*/
/*                 return (this.x1 <= x && x <= this.x2) && (this.y1 <= y && y<= this.y2);*/
/*             }*/
/* */
/*             function getCircleCenter() { return {x: this.x, y: this.y}; }*/
/* */
/*             function getRectangleCenter() { return {x: (this.x2+this.x1)/2, y: (this.y2+this.y1)/2}; }*/
/* */
/*             var objects = [*/
/*                 {x: 100, y: 100, r: 50, isInObject: isInCircle, title: 'big circle', getCenter: getCircleCenter },*/
/*                 {x: 150, y: 250, r: 35, isInObject: isInCircle, title: 'middle circle', getCenter: getCircleCenter },*/
/*                 {x: 500, y: 300, r: 10, isInObject: isInCircle, title: 'small circle', getCenter: getCircleCenter },*/
/*                 {x1: 200, y1: 400, x2: 300, y2: 500, isInObject: isInRectangle, title: 'rectangle', getCenter: getRectangleCenter }*/
/*             ]*/
/* */
/*             function whereIam(x, y) {*/
/*                 for (var i=0; i<objects.length; i++) {*/
/*                     var obj = objects[i];*/
/*                     if (obj.isInObject(x, y))*/
/*                         return obj;*/
/*                 }*/
/* */
/*                 return null;*/
/*             }*/
/* */
/*             function showMe(ev, a) {*/
/*                 $.each(objects, function(i, object) {*/
/*                     if (object.title == $(a).html()) {*/
/*                         var center = object.getCenter();*/
/*                         var offset = viewer.iviewer('imageToContainer', center.x, center.y);*/
/*                         var containerOffset = viewer.iviewer('getContainerOffset');*/
/*                         var pointer = $('#pointer');*/
/*                         offset.x += containerOffset.left - 20;*/
/*                         offset.y += containerOffset.top - 40;*/
/*                         pointer.css('display', 'block');*/
/*                         pointer.css('left', offset.x+'px');*/
/*                         pointer.css('top', offset.y+'px');*/
/*                     }*/
/*                 });*/
/* */
/*                 ev.preventDefault();*/
/*             }*/
/* */
/*             window.showMe = showMe;*/
/* */
/*             viewer = $("#viewer1").iviewer({*/
/*                 src: "/bundles/app/map.jpg",*/
/*                 zoom: 125,*/
/* */
/*                 onClick: function(ev, coords) {*/
/*                     console.log('Mark mountain at ' + coords.x + ", " + coords.y);*/
/*                     var object = whereIam(coords.x, coords.y);*/
/* */
/*                     if (object)*/
/*                         alert('Clicked at ('+coords.x+', '+coords.y+'). This is '+object.title);*/
/*                 },*/
/* */
/*                 onMouseMove: function(ev, coords) {*/
/*                     var object = whereIam(coords.x, coords.y);*/
/* */
/*                     if (object) {*/
/*                         $('#status').html('You are in ('+coords.x.toFixed(1)+', '+coords.y.toFixed(1)+'). This is '+object.title);*/
/*                         this.container.css('cursor', 'crosshair');*/
/*                     } else {*/
/*                         $('#status').html('You are in ('+coords.x.toFixed(1)+', '+coords.y.toFixed(1)+'). This is empty space');*/
/*                         this.container.css('cursor', null);*/
/*                     }*/
/*                 },*/
/* */
/*                 onBeforeDrag: function(ev, coords) {*/
/*                     // remove pointer if image is getting moving*/
/*                     // because it's not actual anymore*/
/*                     $('#pointer').css('display', 'none');*/
/*                     // forbid dragging when cursor is whithin the object*/
/*                     return whereIam(coords.x, coords.y) ? false : true;*/
/*                 },*/
/* */
/*                 onZoom: function(ev) {*/
/*                     // remove pointer if image is resizing*/
/*                     // because it's not actual anymore*/
/*                     $('#pointer').css('display', 'none');*/
/*                 },*/
/* */
/*                 initCallback: function(ev) {*/
/*                     this.container.context.iviewer = this;*/
/*                 }*/
/*             });*/
/*         });*/
/* */
/*         function findCentroid(points) {*/
/*             var centroid = [0, 0];*/
/* */
/*             for (var i = 0; i < points.length; i+=2) {*/
/*                 centroid[0] += points[i];*/
/*                 centroid[1] += points[i+1];*/
/*             }*/
/* */
/*             var totalPoints = points.length/2;*/
/*             centroid[0] = centroid[0] / totalPoints;*/
/*             centroid[1] = centroid[1] / totalPoints;*/
/* */
/*             return centroid;*/
/*         };*/
/* */
/*         function findMidpoint(x1, y1, x2, y2) {*/
/*             return [*/
/*                 (x1 + x2) / 2,*/
/*                 (y1 + y2) / 2*/
/*             ];*/
/*         };*/
/*         function findDistance(x1, y1, x2, y2) {*/
/*             return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));*/
/*         };*/
/* */
/*         function findMinMax(points) {*/
/*             var solution = {*/
/*                 points: 0,*/
/*                 midpoint: [0, 0],*/
/*                 area: 0,*/
/*                 longest: [[0, 0], [0, 0]],*/
/*                 longestDistance: 0,*/
/*                 lowest: [0, 0],*/
/*                 greatest: [0, 0]*/
/*             };*/
/*             for (var i = 0; i < points.length; i+=4) {*/
/*                 var x = points[i],*/
/*                     y = points[i+2],*/
/*                     x2 = points[i+1],*/
/*                     y2 = points[i+3]*/
/*                 ;*/
/*                 if (solution.points == 0) {*/
/*                     var midpoint = findMidpoint(x, y, x2, y2);*/
/*                     var d1 = findDistance(x);*/
/*                     var centroid = findCentroid(points);*/
/* */
/*                     solution = {*/
/*                         points: 1,*/
/*                         midpoint: [centroid[0], centroid[1]],*/
/*                         longest: [[x, y], [x2, y2]],*/
/*                         longestDistance: d1,*/
/*                         area: 0,*/
/*                         lowest: [, 0],*/
/*                         greatest: [0, 0]*/
/*                     };*/
/*                     continue;*/
/*                 }*/
/*             }*/
/*         };*/
/* */
/*         var app = {};*/
/* */
/* */
/*         var editor = new function() {*/
/*             this.mode = null;*/
/*             this.context = null;*/
/*             this.dirty = false;*/
/*             this.data = {*/
/*                 'Mountain': [[*/
/*                     549,194,549,316,563,339,517,372,533,386,566,373,585,370,597,379,637,372,665,365,669,376,717,381,790,399,811,382,807,371,698,329,680,282,663,278,645,292,626,271,604,263,621,247,606,232,597,234,596,198,582,183,568,187*/
/*                 ]],*/
/*                 'Tree': [],*/
/*                 'Water': [],*/
/*                 'Boundary': [],*/
/*                 'Path': [],*/
/*                 'Field': []*/
/*             };*/
/* */
/*             this.reset = function() {*/
/*                 var ctx = $('canvas')[0].getContext('2d');*/
/*                 $('.editor-reset').click();*/
/*                 this.dirty = false;*/
/*                 this.drawLayers();*/
/*             };*/
/* */
/*             this.finish = function() {*/
/*                 var data = this.data[this.mode];*/
/*                 data[data.length] = $('#map-points').val().split(',');*/
/*                 for (var i = 0; i < data.length; i++) {*/
/*                     for (var j = 0; j < data[i].length; j++) {*/
/*                         data[i][j] = parseInt(data[i][j]);*/
/* */
/*                     }*/
/*                 }*/
/*                 this.reset();*/
/*             };*/
/* */
/*             this.drawLayers = function() {*/
/*                 if (!this.context) {*/
/*                     var ctx = $('canvas')[0].getContext('2d');*/
/*                     this.context = ctx;*/
/*                 }*/
/*                 var context = this.context;*/
/*                 console.log(this.data);*/
/*                 for (var mode in this.data) {*/
/*                     for (var i = 0; i < this.data[mode].length; i++) {*/
/* */
/*                         var centroid = findCentroid(this.data[mode][i]);*/
/*                         var base_image = new Image();*/
/*                         base_image.src = 'bundles/app/' + mode.toLowerCase() + '.png';*/
/*                         context.drawImage(base_image, centroid[0] - 50, centroid[1] - 50, 100, 100);*/
/*                     }*/
/*                 }*/
/* */
/* //                console.log(findCentroid(points2));*/
/* //                context.moveTo(20, 20);*/
/* //                context.lineTo(100, 20);*/
/* //                context.fillStyle = "#999";*/
/* //                context.beginPath();*/
/* //                context.arc(100,100,75,0,2*Math.PI);*/
/* //                context.fill();*/
/* //                context.fillStyle = "orange";*/
/* //                context.fillRect(20,20,50,50);*/
/* //                context.font = "24px Helvetica";*/
/* //                context.fillStyle = "#000";*/
/* //                context.fillText("Canvas", 50, 130);*/
/* */
/*             };*/
/*         };*/
/*         $('.editor-mode').change(function() {*/
/*             if (editor.dirty) {*/
/*                 if (!window.confirm('There are unsaved changes.Discard?')) {*/
/*                     return;*/
/*                 }*/
/*             }*/
/*             editor.mode = $(this).val();*/
/*             editor.reset();*/
/*         });*/
/* */
/*         $('.editor-cancel').click(function() {*/
/*             editor.reset();*/
/*         });*/
/* */
/*         $('.editor-finish').click(function() {*/
/*             editor.finish();*/
/*         });*/
/* */
/*         $(document).ready(function() {*/
/* */
/*             $('#mark_mountains').change(function() {*/
/*                 app.mode = 'mark_mountains';*/
/*             });*/
/* */
/* */
/*             window.setTimeout(function() {*/
/*                 editor.reset();*/
/*             }, 500);*/
/*         });*/
/*     </script>*/
/* {% endblock %}*/
/* */
/* {% block additional_stylesheets %}*/
/*     <link rel="stylesheet" href="{{ asset('assets/vendor/iviewer/jquery.iviewer.css') }}" />*/
/*     <style>*/
/*         html, body {*/
/*             height: 100%;*/
/*             padding: 0;*/
/*             margin: 0;*/
/*         }*/
/* */
/*         .viewer*/
/*         {*/
/*             height: 100%;*/
/*             position: relative;*/
/*             background-color: lightgreen;*/
/*         }*/
/* */
/*         .wrapper*/
/*         {*/
/*             border: 1px solid black;*/
/* */
/*             position: absolute;*/
/*             top: 5em;*/
/*             left: 1em;*/
/*             bottom: 1em;*/
/*             right: 1em;*/
/* */
/*             overflow: hidden; /*for opera*//* */
/*         }*/
/* */
/*         .toolbar*/
/*         {*/
/*             border: 1px solid black;*/
/* */
/*             position: absolute;*/
/*             top: 1em;*/
/*             left: 1em;*/
/*             right: 1em;*/
/*             height: 3em;*/
/*         }*/
/* */
/*         #pointer*/
/*         {*/
/*             background-image: url('{{ asset('bundles/app/arrow.png') }}');*/
/*             width: 40px;*/
/*             height: 40px;*/
/*             position: absolute;*/
/*             display: none;*/
/*         }*/
/*         #editor-bar {*/
/*             height: 5em;*/
/*             position: fixed;*/
/*             top: 0;*/
/*             left: 20vw;*/
/*             /*width: 20vw;*//* */
/*             padding: 1vh;*/
/*             vertical-align: text-top;*/
/*             margin: auto;*/
/*             color: white;*/
/*             font-weight: bold;*/
/*             text-align: center;*/
/*             background: rgba(0, 0, 0, 0.4);*/
/* */
/*             /*background: #6a3093; !* fallback for old browsers *!*//* */
/*             /*background: -webkit-linear-gradient(to top, #6a3093 , #a044ff); !* Chrome 10-25, Safari 5.1-6 *!*//* */
/*             /*background: linear-gradient(to top, #6a3093 , #a044ff); !* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ *!*//* */
/* */
/*         }*/
/* */
/*         .editor-button {*/
/*             font-size: 2em;*/
/*             /*width: 3.2em;*//* */
/*             height: 5vh;*/
/*             /*background: rgba(250, 250, 250, 0.7);*//* */
/*             /*background-image: url(...);*//* */
/*             /*background-repeat: no-repeat;*//* */
/*             /*background-position: <left|right>;*//* */
/*             /*padding-<left|right>: <width of image>px;*//* */
/*         }*/
/*         .editor-button > img {*/
/*             height: 4vh;*/
/*             /*width: 3.2em;*//* */
/*             margin-left: -0.2em;*/
/*             margin-topt: -0.8em;*/
/*         }*/
/* */
/*     </style>*/
/*     <link href="{{ asset('assets/vendor/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" />*/
/* {% endblock %}*/
/* */
/* {% import _self as macros %}*/
/* */
/* {% macro button(image, key, title) %}*/
/*         <label class="editor-button btn btn-primary active">*/
/*             <input type="radio" class="editor-button editor-mode btn btn-primary" name="mode" value="{{ title }}">*/
/*                 <img src="{{ asset('bundles/app/' ~ image) }}"    alt="{{ key }}" title="{{ title }}"/>*/
/*             </input>*/
/*         </label>*/
/* {% endmacro %}*/
/* */
/* {% block body %}*/
/*     <div id="editor-bar">*/
/*     <div class="btn-group" data-toggle="buttons">*/
/*         {{ macros.button('mountain.png',    'M', 'Mountain') }}*/
/*         {{ macros.button('water.png',       'W', 'Water') }}*/
/*         {{ macros.button('boundary.png',    'B', 'Boundary') }}*/
/*         {{ macros.button('trees.png',       'T', 'Tree') }}*/
/*         {{ macros.button('path.png',        'P', 'Path') }}*/
/*         {{ macros.button('field.png',       'F', 'Field') }}*/
/*         <button class="editor-button editor-finish btn btn-success">Finish</button>*/
/*         <button class="editor-button editor-cancel btn btn-danger reset">Cancel</button>*/
/*     </div>*/
/*     </div>*/
/*         <form>*/
/*             <div class="row">*/
/*                 <div class="span6">*/
/*       <textarea id="map-points" rows=3 style="display: none; width: 0; height: 0; padding: 0; border: 0;" name="coords1" class="canvas-area input-xxlarge" disabled*/
/*                 placeholder="Shape Coordinates"*/
/*                 data-image-url="{{ asset('bundles/app/map.jpg') }}">549,194,549,316,563,339,517,372,533,386,566,373,585,370,597,379,637,372,665,365,669,376,717,381,790,399,811,382,807,371,698,329,680,282,663,278,645,292,626,271,604,263,621,247,606,232,597,234,596,198,582,183,568,187</textarea>*/
/*                 </div>*/
/*             </div>*/
/*         </form>*/
/* {% endblock %}*/
/* */

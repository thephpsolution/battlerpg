<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_9b42dadf724c9b5518562de2c5b14ab2782e9dc74a81c4c77fce35d199361f5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f81c9d2d488d2deca317a6073dc472d8d084e6886568795eba98d7c496143e36 = $this->env->getExtension("native_profiler");
        $__internal_f81c9d2d488d2deca317a6073dc472d8d084e6886568795eba98d7c496143e36->enter($__internal_f81c9d2d488d2deca317a6073dc472d8d084e6886568795eba98d7c496143e36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f81c9d2d488d2deca317a6073dc472d8d084e6886568795eba98d7c496143e36->leave($__internal_f81c9d2d488d2deca317a6073dc472d8d084e6886568795eba98d7c496143e36_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_fc4f57d74afccecccf244dddcc739f37e585c2e2421cd9c3d4dfc3be5c9b07c1 = $this->env->getExtension("native_profiler");
        $__internal_fc4f57d74afccecccf244dddcc739f37e585c2e2421cd9c3d4dfc3be5c9b07c1->enter($__internal_fc4f57d74afccecccf244dddcc739f37e585c2e2421cd9c3d4dfc3be5c9b07c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_fc4f57d74afccecccf244dddcc739f37e585c2e2421cd9c3d4dfc3be5c9b07c1->leave($__internal_fc4f57d74afccecccf244dddcc739f37e585c2e2421cd9c3d4dfc3be5c9b07c1_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */

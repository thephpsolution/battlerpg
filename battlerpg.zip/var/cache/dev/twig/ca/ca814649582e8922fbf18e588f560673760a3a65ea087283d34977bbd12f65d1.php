<?php

/* ::base.html.twig */
class __TwigTemplate_34e7d2145932ebb75623f512e60a7faa4cf2dc517c430fc0ca6de498b33a71d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce419fa8af71e0166634a9c6a96a6482b37863413aa0548e5bea4561d59a9525 = $this->env->getExtension("native_profiler");
        $__internal_ce419fa8af71e0166634a9c6a96a6482b37863413aa0548e5bea4561d59a9525->enter($__internal_ce419fa8af71e0166634a9c6a96a6482b37863413aa0548e5bea4561d59a9525_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_ce419fa8af71e0166634a9c6a96a6482b37863413aa0548e5bea4561d59a9525->leave($__internal_ce419fa8af71e0166634a9c6a96a6482b37863413aa0548e5bea4561d59a9525_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_cfa123734a6b57fcc48fa317ef74fe1a50fb6f2b221576fdd9ef43a05e6dadbc = $this->env->getExtension("native_profiler");
        $__internal_cfa123734a6b57fcc48fa317ef74fe1a50fb6f2b221576fdd9ef43a05e6dadbc->enter($__internal_cfa123734a6b57fcc48fa317ef74fe1a50fb6f2b221576fdd9ef43a05e6dadbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_cfa123734a6b57fcc48fa317ef74fe1a50fb6f2b221576fdd9ef43a05e6dadbc->leave($__internal_cfa123734a6b57fcc48fa317ef74fe1a50fb6f2b221576fdd9ef43a05e6dadbc_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7a5714a6bb0f13a61cdd38b8c4f714e62f7d39710bbe9be3a0d452cb49742ddb = $this->env->getExtension("native_profiler");
        $__internal_7a5714a6bb0f13a61cdd38b8c4f714e62f7d39710bbe9be3a0d452cb49742ddb->enter($__internal_7a5714a6bb0f13a61cdd38b8c4f714e62f7d39710bbe9be3a0d452cb49742ddb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_7a5714a6bb0f13a61cdd38b8c4f714e62f7d39710bbe9be3a0d452cb49742ddb->leave($__internal_7a5714a6bb0f13a61cdd38b8c4f714e62f7d39710bbe9be3a0d452cb49742ddb_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_54e67c1151d76297eb945c5cd13b9722c4641516ee454ed80363d8645b4a7c1a = $this->env->getExtension("native_profiler");
        $__internal_54e67c1151d76297eb945c5cd13b9722c4641516ee454ed80363d8645b4a7c1a->enter($__internal_54e67c1151d76297eb945c5cd13b9722c4641516ee454ed80363d8645b4a7c1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_54e67c1151d76297eb945c5cd13b9722c4641516ee454ed80363d8645b4a7c1a->leave($__internal_54e67c1151d76297eb945c5cd13b9722c4641516ee454ed80363d8645b4a7c1a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_152cfff9cef48d5b8f44cc61bad1505bd73673b5cff852b21f8c4b0662522a61 = $this->env->getExtension("native_profiler");
        $__internal_152cfff9cef48d5b8f44cc61bad1505bd73673b5cff852b21f8c4b0662522a61->enter($__internal_152cfff9cef48d5b8f44cc61bad1505bd73673b5cff852b21f8c4b0662522a61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_152cfff9cef48d5b8f44cc61bad1505bd73673b5cff852b21f8c4b0662522a61->leave($__internal_152cfff9cef48d5b8f44cc61bad1505bd73673b5cff852b21f8c4b0662522a61_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */

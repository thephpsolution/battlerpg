<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_6a6ad0ae457db0539109ca2f9e918653950e2bb45f690cd9d5384216d18b6caf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Security:login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_830186d2dfa44ab10561c8ce1e702e27302846cd182b519f4d69a48d3838b8fa = $this->env->getExtension("native_profiler");
        $__internal_830186d2dfa44ab10561c8ce1e702e27302846cd182b519f4d69a48d3838b8fa->enter($__internal_830186d2dfa44ab10561c8ce1e702e27302846cd182b519f4d69a48d3838b8fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_830186d2dfa44ab10561c8ce1e702e27302846cd182b519f4d69a48d3838b8fa->leave($__internal_830186d2dfa44ab10561c8ce1e702e27302846cd182b519f4d69a48d3838b8fa_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4ae8803be54e47522d1483f5066febc7fd902ef91ff16d66edc36df53e8e2212 = $this->env->getExtension("native_profiler");
        $__internal_4ae8803be54e47522d1483f5066febc7fd902ef91ff16d66edc36df53e8e2212->enter($__internal_4ae8803be54e47522d1483f5066febc7fd902ef91ff16d66edc36df53e8e2212_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 5
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), array(), "FOSUserBundle"), "html", null, true);
            echo "</div>
";
        }
        // line 7
        echo "
<form action=\"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />

    <label for=\"username\"></label>
    <input style=\"height: 3em;\" placeholder=\"Udsername\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />

    <label for=\"password\"></label>
    <input style=\"height: 3em;\" placeholder=\"Password\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />

    ";
        // line 18
        echo "    ";
        // line 19
        echo "
    <input type=\"submit\" id=\"_submit\" name=\"_submit\" value=\"Login\" />
</form>
";
        
        $__internal_4ae8803be54e47522d1483f5066febc7fd902ef91ff16d66edc36df53e8e2212->leave($__internal_4ae8803be54e47522d1483f5066febc7fd902ef91ff16d66edc36df53e8e2212_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 19,  69 => 18,  61 => 12,  55 => 9,  51 => 8,  48 => 7,  42 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% if error %}*/
/*     <div>{{ error|trans({}, 'FOSUserBundle') }}</div>*/
/* {% endif %}*/
/* */
/* <form action="{{ path("fos_user_security_check") }}" method="post">*/
/*     <input type="hidden" name="_csrf_token" value="{{ csrf_token }}" />*/
/* */
/*     <label for="username"></label>*/
/*     <input style="height: 3em;" placeholder="Udsername" type="text" id="username" name="_username" value="{{ last_username }}" required="required" />*/
/* */
/*     <label for="password"></label>*/
/*     <input style="height: 3em;" placeholder="Password" type="password" id="password" name="_password" required="required" />*/
/* */
/*     {#<input type="checkbox" id="remember_me" name="_remember_me" value="on" />#}*/
/*     {#<label for="remember_me">Remember Me</label>#}*/
/* */
/*     <input type="submit" id="_submit" name="_submit" value="Login" />*/
/* </form>*/
/* {% endblock fos_user_content %}*/
/* */

<?php

/* ::layout.html.twig */
class __TwigTemplate_8e28eb1ee7369180e180138bbaf0351013e2b5d2265ecefb188a2ccc92958681 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "::layout.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'additional_stylesheets' => array($this, 'block_additional_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'additional_javascripts' => array($this, 'block_additional_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c631b18e11d1c479003f91208d8549a9a49e32d9d7eca9d2954a02674fbddfc4 = $this->env->getExtension("native_profiler");
        $__internal_c631b18e11d1c479003f91208d8549a9a49e32d9d7eca9d2954a02674fbddfc4->enter($__internal_c631b18e11d1c479003f91208d8549a9a49e32d9d7eca9d2954a02674fbddfc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c631b18e11d1c479003f91208d8549a9a49e32d9d7eca9d2954a02674fbddfc4->leave($__internal_c631b18e11d1c479003f91208d8549a9a49e32d9d7eca9d2954a02674fbddfc4_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e15edfe2c46290a32eabbff44c947be0f0002f6f12753d1037fad1d94070359f = $this->env->getExtension("native_profiler");
        $__internal_e15edfe2c46290a32eabbff44c947be0f0002f6f12753d1037fad1d94070359f->enter($__internal_e15edfe2c46290a32eabbff44c947be0f0002f6f12753d1037fad1d94070359f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"http://cdn.leafletjs.com/leaflet-0.7.1/leaflet.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/css/bootstrap.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/css/bootstrap-theme.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/_bower.css"), "html", null, true);
        echo "\" />
";
        // line 8
        $this->displayBlock('additional_stylesheets', $context, $blocks);
        
        $__internal_e15edfe2c46290a32eabbff44c947be0f0002f6f12753d1037fad1d94070359f->leave($__internal_e15edfe2c46290a32eabbff44c947be0f0002f6f12753d1037fad1d94070359f_prof);

    }

    public function block_additional_stylesheets($context, array $blocks = array())
    {
        $__internal_ff494bbfc3aa5631c0fec75bee885851e20c12538b266b2bc60055b59fab19a7 = $this->env->getExtension("native_profiler");
        $__internal_ff494bbfc3aa5631c0fec75bee885851e20c12538b266b2bc60055b59fab19a7->enter($__internal_ff494bbfc3aa5631c0fec75bee885851e20c12538b266b2bc60055b59fab19a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_stylesheets"));

        
        $__internal_ff494bbfc3aa5631c0fec75bee885851e20c12538b266b2bc60055b59fab19a7->leave($__internal_ff494bbfc3aa5631c0fec75bee885851e20c12538b266b2bc60055b59fab19a7_prof);

    }

    // line 12
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_0492e8d9d1b84bb0a81bd447fa114f3914e57c10e044f9a5a53d1201f8c5fd02 = $this->env->getExtension("native_profiler");
        $__internal_0492e8d9d1b84bb0a81bd447fa114f3914e57c10e044f9a5a53d1201f8c5fd02->enter($__internal_0492e8d9d1b84bb0a81bd447fa114f3914e57c10e044f9a5a53d1201f8c5fd02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 13
        echo "    ";
        // line 14
        echo "    ";
        // line 15
        echo "        ";
        // line 16
        echo "        ";
        // line 17
        echo "            ";
        // line 18
        echo "        ";
        // line 19
        echo "    ";
        // line 20
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery-ui/jquery-ui.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery-mousewheel/jquery.mousewheel.min.js"), "html", null, true);
        echo "\" ></script>
    <script type=\"text/javascript\" src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/_bower.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/build/mcloutier-battlerpg.min.js"), "html", null, true);
        echo "\"></script>

    ";
        // line 27
        $this->displayBlock('additional_javascripts', $context, $blocks);
        
        $__internal_0492e8d9d1b84bb0a81bd447fa114f3914e57c10e044f9a5a53d1201f8c5fd02->leave($__internal_0492e8d9d1b84bb0a81bd447fa114f3914e57c10e044f9a5a53d1201f8c5fd02_prof);

    }

    public function block_additional_javascripts($context, array $blocks = array())
    {
        $__internal_b2d4c6b68d9a3c9e14e7a6767b5808b3ba53e046af65aecee9080b60afb57237 = $this->env->getExtension("native_profiler");
        $__internal_b2d4c6b68d9a3c9e14e7a6767b5808b3ba53e046af65aecee9080b60afb57237->enter($__internal_b2d4c6b68d9a3c9e14e7a6767b5808b3ba53e046af65aecee9080b60afb57237_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "additional_javascripts"));

        
        $__internal_b2d4c6b68d9a3c9e14e7a6767b5808b3ba53e046af65aecee9080b60afb57237->leave($__internal_b2d4c6b68d9a3c9e14e7a6767b5808b3ba53e046af65aecee9080b60afb57237_prof);

    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 27,  116 => 25,  112 => 24,  108 => 23,  104 => 22,  100 => 21,  95 => 20,  93 => 19,  91 => 18,  89 => 17,  87 => 16,  85 => 15,  83 => 14,  81 => 13,  75 => 12,  58 => 8,  54 => 7,  50 => 6,  46 => 5,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "base.html.twig" %}*/
/* */
/* {% block stylesheets %}*/
/*     <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.1/leaflet.css" />*/
/*     <link rel="stylesheet" href="{{ asset('assets/vendor/bootstrap/dist/css/bootstrap.min.css') }}" />*/
/*     <link rel="stylesheet" href="{{ asset('assets/vendor/bootstrap/dist/css/bootstrap-theme.min.css') }}" />*/
/*     <link rel="stylesheet" href="{{ asset('build/_bower.css') }}" />*/
/* {% block additional_stylesheets %}*/
/* {% endblock %}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {#<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.2.6/angular.min.js"></script>#}*/
/*     {#<script>#}*/
/*         {#var app = angular.module("battlerpg", ['leaflet-directive']);#}*/
/*         {#app.controller("BattleRpg", [ "$scope", function($scope) {#}*/
/*             {#// Nothing here!#}*/
/*         {#}]);#}*/
/*     {#</script>#}*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery/dist/jquery.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery-ui/jquery-ui.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/jquery-mousewheel/jquery.mousewheel.min.js') }}" ></script>*/
/*     <script type="text/javascript" src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.min.js') }}"></script>*/
/*     <script type="text/javascript" src="{{ asset('build/_bower.js') }}"></script>*/
/*     <script type="text/javascript" src="{{ asset('bundles/build/mcloutier-battlerpg.min.js') }}"></script>*/
/* */
/*     {% block additional_javascripts %}*/
/* {% endblock %}*/
/* {% endblock %}*/

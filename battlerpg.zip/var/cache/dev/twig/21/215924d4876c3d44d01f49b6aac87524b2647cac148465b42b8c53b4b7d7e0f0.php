<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_55a3a590e20f11cc55f011603eaa50951819ca09b94d95a85972aa0f47490420 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::layout.html.twig", "FOSUserBundle::layout.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee468b51840324bc3e686f13684f75ba5e563fc63b17a540e2106aa63b3a6e91 = $this->env->getExtension("native_profiler");
        $__internal_ee468b51840324bc3e686f13684f75ba5e563fc63b17a540e2106aa63b3a6e91->enter($__internal_ee468b51840324bc3e686f13684f75ba5e563fc63b17a540e2106aa63b3a6e91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ee468b51840324bc3e686f13684f75ba5e563fc63b17a540e2106aa63b3a6e91->leave($__internal_ee468b51840324bc3e686f13684f75ba5e563fc63b17a540e2106aa63b3a6e91_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_88c00609e4a336dfb95ea80071154e07ff71f1c3ae6edb0a897dea8e534241f0 = $this->env->getExtension("native_profiler");
        $__internal_88c00609e4a336dfb95ea80071154e07ff71f1c3ae6edb0a897dea8e534241f0->enter($__internal_88c00609e4a336dfb95ea80071154e07ff71f1c3ae6edb0a897dea8e534241f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_88c00609e4a336dfb95ea80071154e07ff71f1c3ae6edb0a897dea8e534241f0->leave($__internal_88c00609e4a336dfb95ea80071154e07ff71f1c3ae6edb0a897dea8e534241f0_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_57085a5bb9e9a37dd0f13e7d3fd2b6dda822fc70ce4f8056da2dfa547900e0b3 = $this->env->getExtension("native_profiler");
        $__internal_57085a5bb9e9a37dd0f13e7d3fd2b6dda822fc70ce4f8056da2dfa547900e0b3->enter($__internal_57085a5bb9e9a37dd0f13e7d3fd2b6dda822fc70ce4f8056da2dfa547900e0b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        
        $__internal_57085a5bb9e9a37dd0f13e7d3fd2b6dda822fc70ce4f8056da2dfa547900e0b3->leave($__internal_57085a5bb9e9a37dd0f13e7d3fd2b6dda822fc70ce4f8056da2dfa547900e0b3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends "::layout.html.twig" %}*/
/* {% block body %}*/
/*     {% block fos_user_content %}{% endblock %}*/
/* {% endblock %}*/
